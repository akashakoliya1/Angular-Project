
const adminCredentials = {
    email: "admin@example.com",
    password: "admin123"
};


if (!localStorage.getItem("admin")) {
    localStorage.setItem("admin", JSON.stringify(adminCredentials));
}

function getUsers() {
    return JSON.parse(localStorage.getItem("users")) || [];
}


function saveUsers(users) {
    localStorage.setItem("users", JSON.stringify(users));
}


function getAdminSession() {
    return JSON.parse(localStorage.getItem("adminSession"));
}


function saveAdminSession(admin) {
    localStorage.setItem("adminSession", JSON.stringify(admin));
}


function clearAdminSession() {
    localStorage.removeItem("adminSession");
}

// manage Admin Login
document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("adminLoginForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const email = document.getElementById("adminEmail").value;
            const password = document.getElementById("adminPassword").value;
            const storedAdmin = JSON.parse(localStorage.getItem("admin"));

            if (email === storedAdmin.email && password === storedAdmin.password) {
                saveAdminSession(storedAdmin);
                alert("Login Successful!");
                window.location.href = "admin1.html";
            } else {
                alert("Invalid Credentials!");
            }
        });
    }

    //Ifon dashboard page
    if (window.location.pathname.includes("admin1.html")) {
        if (!getAdminSession()) {
            alert("You must be logged in as admin!");
            window.location.href = "admin1.html";
        }

        loadUsers();
    }

    // Logout
    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", function () {
            clearAdminSession();
            alert("Logged out successfully!");
            window.location.href = "admin.html";
        });
    }
});

// Dashboard Table
function loadUsers() {
    const users = getUsers();
    const userTable = document.getElementById("userTable");
    userTable.innerHTML = "";

    users.forEach((user, index) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${user.email}</td>
            <td>${user.firstname} ${user.lastname}</td>
            <td><button class="delete-btn" onclick="deleteUser(${index})">Delete</button></td>
        `;
        userTable.appendChild(row);
    });
}

//Delete
function deleteUser(index) {
    let users = getUsers();
    if (confirm("Are you sure you want to delete this user?")) {
        users.splice(index, 1);
        saveUsers(users);
        loadUsers();
        alert("User deleted successfully!");
    }
}
