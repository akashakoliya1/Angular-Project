// Function to get all users from localStorage
function getUsers() {
    return JSON.parse(localStorage.getItem("users")) || [];
}

// Function to save updated users to localStorage
function saveUsers(users) {
    localStorage.setItem("users", JSON.stringify(users));
}

// Forgot Password Functionality
document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("forgotPasswordForm").addEventListener("submit", function (e) {
        e.preventDefault(); // Prevent form from reloading the page

        const email = document.getElementById("forgotEmail").value;
        let users = getUsers();

        // Check if email exists in registered users
        const userIndex = users.findIndex(user => user.email === email);

        if (userIndex !== -1) {
            // Prompt user to enter a new password
            const newPassword = prompt("Enter your new password:");

            if (newPassword && newPassword.trim().length >= 6) {
                users[userIndex].password = btoa(newPassword); // Encrypt and update password
                saveUsers(users); // Save updated users
                alert("Password reset successfully! Please login with your new password.");
                window.location.href = "index.html"; // Redirect to login page
            } else {
                alert("Password must be at least 6 characters long.");
            }
        } else {
            alert("Email not found! Please enter a registered email.");
        }
    });
});
