function saveUsers(users){
    localStorage.getItem("users" , JSON.stringify(users));
}

function getUsers(){
    return JSON.parse(localStorage.getItem("users")) || [];
}

function getSession(){
    return JSON.parse(localStorage.getItem("session"));
}

function saveSession(user){
    localStorage.setItem("session" , JSON.stringify(user));
}

function updateLocalStorageUser(user){
    localStorage.setItem('users', JSON.stringify(user));
}

function clearSession(){
    localStorage.removeItem("session");
}

document.addEventListener("DOMContentLoaded" , function(){
    const session = getSession()
    if(!session){
    alert("you must be logged in to access this page");
    window.location.href = "index.html";
    return;
    }

    document.getElementById("firstName").value = session.firstname;
    document.getElementById("lastName").value = session.lastname;
    document.getElementById("email").value = session.email;
    document.getElementById("mobile").value = session.mobile;

    // save data
    document.getElementById("update_profile").addEventListener("click" , function(){
    const users = getUsers();
    const userIndex = users.findIndex( 
        (user) => user.email === session.email
    );
    const firstname = document.getElementById("firstName").value;
    const lastname = document.getElementById("lastName").value;
    const email = document.getElementById("email").value;
    const mobile = document.getElementById("mobile").value;
    const password = btoa(document.getElementById("password").value);
        // object
         users[userIndex] = {
            ...users[userIndex],
            firstname,
            lastname,
            email,
            mobile,
            password
        };
    // users.push({ firstname, lastname, email, password })

        // data update from aaray
        saveSession(users[userIndex]);// object
        updateLocalStorageUser(users);//array to object
        alert("profile update successfully!");
        window.location.href = "admin1.html";
    
    })

    // delete account

    document.getElementById("profile_del").addEventListener("click" , function(){
        if(confirm("Are you sure you want to delete your account?")){
            let users = getUsers();
            users = users.filter( 
                (user) => user.username !== session.username
            );
                saveUsers(users);
                clearSession();
                alert("Account deleted successfully.");
                window.location.href = "index.html";
            }
    });

    //logout
    document.getElementById("profile_log").addEventListener("click", function(){
        clearSession();
        alert("Logged out successfuliy.");
        window.location.href = "index.html";
    });

    // admin login page
    // document.getElementById("admin").addEventListener("click",function(){
    //     clearSession();
    //     window.location.href = "admin.html";
    // });


    // profile photo
        // Default Profile Photo
    const defaultProfilePhoto = "/img/user.png";

    //Profile Photo on Page Load
    document.addEventListener("DOMContentLoaded", function () {
    const profileImg = document.getElementById("profileImage");
    const savedPhoto = localStorage.getItem("profilePhoto");

    //Setthe saved photo or default photo
    profileImg.src = savedPhoto ? savedPhoto : defaultProfilePhoto;
    });

    //Preview PhotoChanging
    document.getElementById("uploadPhoto").addEventListener("change", function (event) {
    const profileImg = document.getElementById("profileImage");
    const file = event.target.files[0];

    if (file) {
        const reader = new FileReader();

        reader.onload = function (e) {
        profileImg.src = e.target.result; //Show the new image preview
        localStorage.setItem("profilePhoto", e.target.result); //Save to localStorage
        alert("Profile photo updated successfully!");
        };

        reader.readAsDataURL(file); //Convert file to Base64
    } else {
        alert("Please select a valid image file.");
    }
    });
});