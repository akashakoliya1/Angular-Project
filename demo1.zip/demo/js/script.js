console.log("hello");
const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const iconClose = document.querySelector('.icon-close');
const btnPopup = document.querySelector('.btnLogin-popup');
const iconCloseReg = document.querySelector('.icon-close-reg');

registerLink.addEventListener('click' , () => {
    wrapper.classList.add('active');
});

loginLink.addEventListener('click' , () => {
    wrapper.classList.remove('active');
});



// btnPopup.addEventListener('click' , () => {
//     wrapper.classList.add('active-popup');
// });


// iconClose.addEventListener('click' , () => {
//     wrapper.classList.remove('active-popup');
// });


// iconCloseReg.addEventListener('click' , () => {
//     wrapper.classList.remove('active-popup');
// });

function saveUsers(users) {
    localStorage.setItem("users",JSON.stringify(users));
}

function getUsers() {
    return JSON.parse(localStorage.getItem("users"))  || [];
}

document.getElementById("register").addEventListener("submit",function(e) {
    e.preventDefault();

    const firstname = document.getElementById("fName").value;
    const lastname = document.getElementById("lName").value;
    const email = document.getElementById("rEmail").value;
    const mobile = document.getElementById("mobile").value;
    const password = btoa(document.getElementById("rPassword").value);

    const users = getUsers();
    if (users.some((user) => user.email === email)) {
      alert("Email already exists.");
      return;
    }
  
    users.push({ firstname, lastname, email, mobile, password });
    saveUsers(users);
    alert("Registration successful. Please login.");
    window.location.href = "index.html";

  });

  // login //

function saveSession(user) {
    localStorage.setItem("session", JSON.stringify(user));
  }

  document.addEventListener("DOMContentLoaded",function(){
    console.log("DOM fully loaded");

    const loginForm = document.getElementById("login");
  const loginEmail = document.getElementById("lemail");
  const loginPassword = document.getElementById("lpass");

  console.log("Login form:", loginForm);
  console.log("Login email:", loginEmail);
  console.log("Login password:", loginPassword);

  if (loginForm && loginEmail && loginPassword) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault(); // prevent to page reload nai thava dey

      const email = loginEmail.value;
      const password = btoa(loginPassword.value); // Encrypt password to compare

      const users = getUsers(); // Fetch users data
      const user = users.find(
        (user) => user.email === email && user.password === password
      );

      if (user) {
        saveSession(user); // Save session on successful login
        alert("Login successful!");
        window.location.href = "profile.html"; // Redirect to profile page
      } else {
        alert("Invalid email or password.");
      }
    });
  } else {
    console.error("One or more elements are missing in the DOM");
  }
  })